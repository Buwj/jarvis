#this is a work in progress, the jokes havent been included yet.

What did the green grape say to the purple grape?\nBREATHE STUPID!",
	"What happens to a frog's car when it breaks down?\nIt gets toad away.",
	
  "Why isn't the turkey hungry at Thanks giving?\nBecause it's stuffed.",
	
  "Why do witches wear name tags?\nSo they know which witch is which.",
	
  "My friend thinks he is so smart, told me today that onion is the only food that makes you cry\nSo I threw a coconut at his face.",
	
  "What stays in one corner but travels around the world?\nA stamp.",
		
  "What do you call a pig that does karate?\nPork chop.",
		
  "Why does Humpty Dumpty love autumn?\nBecause he had a great fall last year.",
	
  "Did you hear about the kidnapping at school today?\nIt's alright, he's awake now.",
	
  "Have you heard about the new restaurant Karma?\nThere's no menu, you get what you deserve
